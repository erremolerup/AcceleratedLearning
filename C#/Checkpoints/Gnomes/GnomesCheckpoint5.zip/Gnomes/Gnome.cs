﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gnomes
{
    public class Gnome
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Beard { get; set; }
        public string Intention { get; set; }
        public int Temper { get; set; }
        public string Type { get; set; }
    }
}
