﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace Gnomes
{
    public class DataAccess
    {
        public string conString = "Server = (localdb)\\mssqllocaldb; Database = GnomeDb";

        internal List<Gnome> GetGnomesFromDatabase()
        {
            var sql = @"SELECT * FROM Gnome";

            using (SqlConnection connection = new SqlConnection(conString))
            using (SqlCommand command = new SqlCommand(sql, connection))
            {
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                var list = new List<Gnome>();

                while (reader.Read())
                {
                    var gn = new Gnome
                    {
                        Id = reader.GetSqlInt32(0).Value,
                        Name = reader.GetSqlString(1).Value
                    };
                    list.Add(gn);
                }
                return list;
            }
        }
    }
}
