﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Checkpoint01
{
    class Program
    {
        static void Main(string[] args)
        {
            string numbersTogether = AskUserForNumbers();
            string[] numbers = CreateArrayOfNumbers(numbersTogether);
            DrawTriangle(3, 3);

            //while (true)
            //{
            //    string numbersTogether = AskUserForNumbers();
            //    numbers = CreateArrayOfNumbers(numbersTogether);
            //    RemoveBlandSpaces(numbers);
            //    if (numberIsValid(numbers))
            //    {
            //        break;
            //    }
            //}
        }

        //GET LIST OF NUMBERS FROM USER
        private static string AskUserForNumbers()
        {
            Console.Write("Write command: ");
            string numbersTogether = Console.ReadLine();

            return numbersTogether;
        }

        //CREATE LIST
        private static string[] CreateArrayOfNumbers(string numbersTogether)
        {
            string[] numbers = numbersTogether.Split(new[] { '-' });
            
            return numbers;
        }

        //VALIDATE USER INPUT
        //private static int numbersIsValid(string[] numbers)
        //{
        //    if ()
        //    {

        //    }
        //}

        //REPORT TO USER
        private static void DrawTriangle(int x, int y)
        {
            //foreach (var number in numbers)
            //{

                for (int i = 0; i < x; i++)
                {
                    for (int j = 0; j < x; j++)
                    {
                        Console.Write("");
                    }
                    for (int k = 0; k < i; k++)
                    {
                        Console.Write("*");
                    }
                    Console.WriteLine("*");
                }
                //foreach (var number in numbers)
                //{
                //    int number = 0;
                //    int i, j;

                //    //if (int.TryParse(Console.ReadLine(), out number))
                //    //{
                //    for (i = 0; i < number; i++)
                //    {
                //        int numberOfSpaces = i;
                //        int numberOfStars = (number * 2 - 1) - (2 * numberOfSpaces);

                //        for (j = 0; j <= numberOfStars; j++)
                //        {
                //            Console.Write("*");
                //        }
                //    }
                //}
            //}
        }        
    }
}

