﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HemNet.Models
{
    public class SiteConfig
    {
        public string WelcomeMessage { get; set; }
        public bool ShowContactLink { get; set; }
    }
}
