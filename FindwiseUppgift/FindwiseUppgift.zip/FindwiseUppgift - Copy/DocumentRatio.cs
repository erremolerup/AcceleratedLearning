﻿namespace FindwiseUppgift
{
    public class DocumentRatio
    {
        public int Id { get; set; }
        public decimal Ratio { get; set; }
    }
}
